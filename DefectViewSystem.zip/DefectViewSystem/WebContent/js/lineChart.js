$(function() {
    $('#lineChart').highcharts({
        chart: {
            type: 'line'
        },
        credits: {
            enabled: false
        },
        title: {
            text: 'Bug Trend'
        },
        subtitle: {
            text: 'Open Bugs Of Different Priority'
        },
        xAxis: {
            labels:{
                enabled:false
                },
        },
        yAxis: {
            min: 0,
            max: 40,
            tickInterval: 5,
            title: {
                text: 'Bugs Priority'
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: false
                },
                enableMouseTracking: true

            }
        },
        series: [{
            name: 'P1(Open Bugs)',
            data: [7, 6, 9, 14, 18, 21, 25, 26]
        }, {
            name: 'P2(Open Bugs)',
            data: [3, 4, 5, 8, 11, 15, 17, 16]
        }, {
            name: 'P3(Open Bugs)',
            data: [3, 4, 6, 9, 6, 8, 17, 16]
        }]
        
    });
});
$(document).ready(function() {
    $("#myTable").DataTable({
        "scrollX": true
    });
});