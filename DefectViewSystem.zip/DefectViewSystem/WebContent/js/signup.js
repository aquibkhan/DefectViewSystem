/*This function is for form validation*/
function saveData() {
    var namepattern = /^[a-zA-Z ]{2,30}$/;
    /* first name field should not be empty*/
    if (document.sign_up.fname.value === "" | !document.sign_up.fname.value.match(namepattern)) {
        document.getElementById("fname_error").innerHTML = "enter valid name";
        return false;
    }
    else {
        document.getElementById("fname_error").innerHTML = "";
    }
    /*Last name field should not be empty*/
    if (document.sign_up.lname.value === "" | !document.sign_up.lname.value.match(namepattern)) {
        document.getElementById("lname_error").innerHTML = "enter your valid last name";
        return false;
    }
     else {
        document.getElementById("lname_error").innerHTML = "";
    }
    var emailID = document.sign_up.useremail.value;
    var cnfemail = document.sign_up.cnfrm.value;
    var pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    /* email address field should not be empty*/
    if (document.sign_up.useremail.value === "" | !document.sign_up.useremail.value.match(pattern) ) {
        document.getElementById("email_error").innerHTML = "enter valid email";
        return false;

    }
    else {
        document.getElementById("email_error").innerHTML = "";
    }
    /* This field should not be empty*/
    if (document.sign_up.cnfrm.value === "") {
        document.getElementById("cnfrm_error").innerHTML = "re-enter your email";
        return false;
    } else {
        document.getElementById("cnfrm_error").innerHTML = "";
    }
    /*The two emails should be the same.*/
    if (emailID !== cnfemail) {
        document.getElementById("email_error").innerHTML = "emails do not match";
        return false
    } else {
        document.getElementById("email_error").innerHTML = "";
    }
    /*Password field cannot be empty*/
    if (document.sign_up.userpassword.value === "") {
        document.getElementById("pswrd_error").innerHTML = "enter your password";
        return false;
    } else {
        document.getElementById("pswrd_error").innerHTML = "";
    }

}