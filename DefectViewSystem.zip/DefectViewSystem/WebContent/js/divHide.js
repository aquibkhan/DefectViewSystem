
        function pieEffect(){
            document.getElementById("lineChart").parentNode.style.display='none'; 
            document.getElementById("dataTable").parentNode.style.display='none';
            document.getElementById("pieChart").parentNode.style.display='block';  
        }
        function lineEffect(){
            document.getElementById("lineChart").parentNode.style.display='block'; 
            document.getElementById("dataTable").parentNode.style.display='none';
            document.getElementById("pieChart").parentNode.style.display='none';   
        }
        function tableEffect(){
            document.getElementById("lineChart").parentNode.style.display='none'; 
            document.getElementById("dataTable").parentNode.style.display='block'; 
            document.getElementById("pieChart").parentNode.style.display='none'; 
             
        }
      