
// Below function Executes on click of login button.
function validate(){
var username = document.getElementById("inputEmail").value;
var pass = document.login_form.pswrd.value;
if(username=="")
{
	document.getElementById("email_error").innerHTML="enter your email"
	return false;
}
    else{
        document.getElementById("email_error").innerHTML="";
        
    }
if(pass=="")
{
	document.getElementById("pswrd_error").innerHTML="enter your password";
	return false;
}
    else{
      document.getElementById("pswrd_error").innerHTML="";
    }
    if( username == "aquib.rajat@gmail.com" && pass == "123"){
   // document.login_form.action="../homePage.html";
    window.location.assign("index.html"); // Redirecting to other page.
    return false;
}
    else{
    alert ("Invalid Login");
        return false;
    }
}