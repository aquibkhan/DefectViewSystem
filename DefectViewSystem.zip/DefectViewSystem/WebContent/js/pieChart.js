$(function() {
    Highcharts.setOptions({
        colors: ['red', '#ED561B', '#50B432']
    });
    $(document).ready(function() {
        // Build the chart
        $('#pieChart').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Defects Priority'
            },
            credits: {
                enabled: false
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    point: {
                    events: {
                        click: function () {
							var nameSeries =this.name;
							if(nameSeries === "P1") {
								p1LineChart();
							} else if(nameSeries === "P2") {
								p2LineChart();
							} else if(nameSeries === "P3") {
								p3LineChart();
							}
                    
                        }
                    }
                },
                    dataLabels: {
                    enabled: false
                    },
                    dataLabels: {
                        distance: -30,
                        color: 'white'
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Defects',
                colorByPoint: true,
                data: [{
                    name: 'P1',
                    y: 40,
                    
                },{
                    name: 'P2',
                    y: 30,
                    sliced: true,
                    selected: true
                }, {
                    name: 'P3',
                    y: 30
                }, ]
            }]
        });
    });
});
/*function for p1 priority lineChart*/
function p1LineChart(){
     Highcharts.setOptions({
        colors: ['black', 'grey']
    });
	$('#lineChart').highcharts({
        chart: {
            type: 'line'
        },
        tooltip: {
     formatter: function() {
               return  this.point.myData;
            }     
         },
        credits: {
            enabled: false
        },
        title: {
            text: 'Bug Trend(Open/Close Bugs)'
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            labels:{
            enabled:false
        },   
        },
        yAxis: {
            min: 0,
            max: 40,
            tickInterval: 5,
            title: {
                text: 'Bugs Priority'
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: false
                },
                enableMouseTracking: true,
               

            },
            
        },
         series: [{
            name: 'P1(Open Bugs)',
            data: [ { 
                y : 4, myData : 'Created On:11/02' 
            },
                 { 
                    y : 7, myData : 'Created On:11/02'
                 },
                 { 
                     y : 9, myData : 'Created On:11/02'
                 },
                   { 
                       y : 12, myData : 'Created On:11/02'
                   }]
        },{
            name: 'P1(Closed Bugs)',
            data: [ {
                y : 3, myData :'Resolved On:14/02' 
            },
                 { 
                     y : 4, myData :'Resolved On:13/02' 
                 },
                 { 
                     y : 6, myData :'Resolved On:14/02'
                 },
                   { 
                       y : 8, myData :'Resolved On:12/02'
                   }]
        }]
        
    });
}
/*function for p2 priority lineChart*/
function p2LineChart(){
     Highcharts.setOptions({
        colors: ['black', 'grey']
    });
	$('#lineChart').highcharts({
        chart: {
            type: 'line'
        },
         tooltip: {
     formatter: function() {
               return  this.point.myData +'</b>';
            }
         },
        credits: {
            enabled: false
        },
        title: {
            text: 'Bug Trend(Open/Close Bugs)'
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            labels:{
                enabled:false
            },
           
        },
        yAxis: {
            min: 0,
            max: 40,
            tickInterval: 5,
            title: {
                text: 'Bugs Priority'
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: false
                },
                enableMouseTracking: true,
               

            },
            
        },
        series: [{
            name: 'P2(Open Bugs)',
            data: [ {
                y : 2, myData :'Created On:11/02'
            },
                 { 
                     y : 5, myData : 'Created On:15/02'
                 },
                 {
                     y : 9, myData : 'Created On:13/02' 
                 },
                   { 
                       y : 12, myData : 'Created On:17/02'
                   }]
        },{
            name: 'P2(Closed Bugs)',
           data: [ 
               { y : 1, myData :'Resolved On:11/02' 
               },
                 { 
                     y : 2, myData :'Resolved On:11/02' 
                 },
                 { 
                     y : 3, myData :'Resolved On:11/02' 
                 },
                   {
                       y : 5, myData:'Resolved On:11/02'
                   }]
        }]
        
    });
}
/*function for p3 priority lineChart*/
function p3LineChart(){
     Highcharts.setOptions({
        colors: ['black', 'grey']
    });
	$('#lineChart').highcharts({
        chart: {
            type: 'line'
        },
         tooltip: {
     formatter: function() {
               return  this.point.myData +'</b>';
            }
         },
        credits: {
            enabled: false
        },
        title: {
            text: 'Bug Trend(Open/Close Bugs)'
        },
        xAxis: {
            labels:{
                enabled:false
            },
           
        },
        yAxis: {
            min: 0,
            max: 40,
            tickInterval: 5,
            title: {
                text: 'Bugs Priority'
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: false
                },
                enableMouseTracking: true,   
            },   
        },
        series: [{
            name: 'P3(Open Bugs)',
             data: [ {
                 y : 5, myData : 'Created on:25/02'
             },
                 {
                     y : 7, myData : 'Created on:25/02'
                 },
                 {
                     y : 8, myData : 'Created on:25/02'
                 },
                   { 
                       y : 10, myData : 'Created on:25/02'
                   }]
        },{
            name: 'P3(Closed Bugs)',
             data: [ { 
                    y : 3, myData : 'Resolved on:25/02'
             },
                 {
                     y : 4, myData : 'Resolved on:23/02'
                 },
                 {
                     y : 6, myData : 'Resolved on:21/02'
                 },
                   {
                       y : 0, myData : 'Resolved on:18/02'
                   }]
        }]
        
    });
}