package servletsLogin;

import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.RequestDispatcher;  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;

import servletLoginAutenticate.LoginDao;

public class LoginServlet extends HttpServlet {  
  
    /**
	 * 
	 */
	private static final long serialVersionUID = -6718822325731444358L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)    
            throws ServletException, IOException {    
  
        response.setContentType("text/html");    
        PrintWriter result = response.getWriter();    
          
        String username= request.getParameter("username");    
        String password= request.getParameter("userpass");   
          
        if (LoginDao.validate(username, password)){
        	 HttpSession session = request.getSession();
        	 session.setAttribute("username", username); 
            RequestDispatcher rd=request.getRequestDispatcher("index.jsp");    
            rd.forward(request,response);    
        } else {    
	        	result.println("<script type=\"text/javascript\">");
	        	result.println("alert('User or password incorrect');"); 
	        	result.println("</script>");
	            RequestDispatcher rd=request.getRequestDispatcher("login.html");    
	            rd.include(request,response);    
        }    
  
        result.close();
       
    }    
} 
