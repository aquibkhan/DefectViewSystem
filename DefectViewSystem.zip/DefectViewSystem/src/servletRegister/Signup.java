package servletRegister;

import java.io.*;  
import java.sql.*;  

import javax.servlet.ServletException;  
import javax.servlet.http.*; 

import connection.ConnectionProvider;
  
public class Signup extends HttpServlet { 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1576881255136084679L;
	/**
	 * 
	 */
	
	static Connection connection=ConnectionProvider.connection();
public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
  
response.setContentType("text/html");  
PrintWriter result = response.getWriter();  
          
String name=request.getParameter("fname");  
String lastName=request.getParameter("lname");  
String uemail=request.getParameter("useremail");  
String upassword=request.getParameter("userpassword");  
          
try{  

  
PreparedStatement ps=connection.prepareStatement(  
"insert into register(firstName,lastName,email,usr_password) values(?,?,?,?)");  
ps.setString(1,name);  
ps.setString(2,lastName);  
ps.setString(3,uemail);  
ps.setString(4,upassword);  
          
int i=ps.executeUpdate();  
if(i>0) { 
	result.println("<script type=\"text/javascript\">");
	result.println("window.location.assign('login.html')"); 
	result.println("</script>");
}
      
          
}catch (Exception e2) {System.out.println(e2);}  
          
result.close();  
}  
  
}  
