package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionProvider {
	public static Connection conn;
	 public static Connection connection() {          
	        String url = "jdbc:mysql://localhost:3306/";  
	        String dbName = "bugs";  
	        String driver = "com.mysql.jdbc.Driver";  
	        String userName = "root";  
	        String password = "root";  
	        try {  
	            Class.forName(driver).newInstance();  
	            conn = DriverManager.getConnection(url + dbName, userName, password);
	           
	        } catch (Exception e) {  
	            System.out.println(e);  
	        }
	        return conn;    
	 }
}


